import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { PanelMenu } from 'primeng/panelmenu';

@Component({
  selector: 'app-aside',
  standalone: true,
  imports: [PanelMenu],
  templateUrl: './aside.html',
  styleUrl: './aside.css'
})
export class Aside {
  items: MenuItem[] = [

    {label: 'Inicio', icon: 'pi pi-fw pi-home',routerLink: '/inicio' },
    { label: 'Destinos turísticos', icon: 'pi pi-fw pi-map',routerLink: '/destinos'},
    {label: 'Alojamientos',icon: 'pi pi-fw pi-building',routerLink: '/alojamientos'},
    {label: 'Paquetes turísticos',icon: 'pi pi-fw pi-ticket',routerLink: '/paquetes'},
    {label: 'Reservas',icon: 'pi pi-fw pi-calendar',routerLink: '/reservas'},
    {label: 'Servicios turísticos',icon: 'pi pi-fw pi-compass',routerLink: '/servicios'},
    {label: 'Usuarios',icon: 'pi pi-fw pi-users',routerLink: '/usuarios'}
  ];
}