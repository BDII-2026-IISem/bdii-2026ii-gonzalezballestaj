import { Routes } from '@angular/router';
import { Home } from './components/home/home';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'inicio',
    pathMatch: 'full'
  },
  {
    path: 'inicio',
    component: Home
  },
  {
    path: 'destinos',
    loadChildren: () =>
      import('./components/destination/destination.routes')
        .then(m => m.DESTINATION_ROUTES)
  },
  {
    path: 'alojamientos',
    loadChildren: () =>
      import('./components/accommodation/accommodation.routes')
        .then(m => m.ACCOMMODATION_ROUTES)
  },
  {
    path: 'paquetes',
    loadChildren: () =>
      import('./components/package/package.routes')
        .then(m => m.PACKAGE_ROUTES)
  },
  {
    path: 'reservas',
    loadChildren: () =>
      import('./components/reservation/reservation.routes')
        .then(m => m.RESERVATION_ROUTES)
  },
  {
    path: 'servicios',
    loadChildren: () =>
      import('./components/service/service.routes')
        .then(m => m.SERVICE_ROUTES)
  },
  {
    path: 'usuarios',
    loadChildren: () =>
      import('./components/user/user.routes')
        .then(m => m.USER_ROUTES)
  },
  {
    path: '**',
    redirectTo: 'inicio'
  }
];